package com.example.spring_boot_postgresql_crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootPostgresqlCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
